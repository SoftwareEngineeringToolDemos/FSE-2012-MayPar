
Using the tool MayPar

1. Open the terminal
2. Go to the bin directory, where the MayPar binary is available
3. Run the following command:-

MayPar main -i '../examples/DemoExample.abs' -v 3 -mode complete -l

4. You will see the desired output

